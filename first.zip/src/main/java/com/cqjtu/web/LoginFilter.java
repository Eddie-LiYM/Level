package com.cqjtu.web;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cqjtu.pojo.Emp;

/**
 * Servlet Filter implementation class LoginFilter
 */
public class LoginFilter implements Filter {


    public LoginFilter() {

    }

	public void destroy() {

	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;   
        HttpServletResponse res = (HttpServletResponse) response;
        request.setCharacterEncoding("UTF-8");  
        response.setCharacterEncoding("UTF-8");  
        response.setContentType("text/html;charset=UTF-8");  
        String path = req.getRequestURI();
        HttpSession session = req.getSession();
       //req.getSession().setAttribute("emp", emp);
        Emp emp=  (Emp) session.getAttribute("emp");
        if(path.indexOf("/login1.jsp")>-1){//登录页面不过滤
            chain.doFilter(request, response);//递交给下一个过滤器
            return;
        }
        if(path.indexOf("/register.jsp")>-1){//注册页面不过滤
            chain.doFilter(request, response);
            return;
        } 
        if(emp!=null){//已经登录
            chain.doFilter(request, response);//放行，递交给下一个过滤器
            
        }else{
            //((HttpServletResponse) response).sendRedirect("login1.jsp");//重定向到登录页面
            res.sendRedirect("login1.jsp");
        }
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
